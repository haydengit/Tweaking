This guide is for 1809- so if u are in 1903+ . Keep safe with these indications.

Make sure u use OpenShell, StartIsBack, or bblean (blackbox) {these applications replace start menu}
Make sure u strip ur Bloatware before using DCKiller.
If u don't want to use these apps keep safe following these steps.

Delete 1 WIndowsApps          
       2 Packages        
       3 WindowsApps
       5 Systemapps

                                         |1 WIndowsApps|         
                                         |2 Packages|        
                                         |3 WindowsApps| are just shortcuts u have to double click them to go to the actual folders to debloat so make sure u don't delete the shortcuts        
                                         |4 Packages|                                                                                             U HAVE TO DELETE THE ACTUAL FOLDERS
                                         |5 Systemapps|
 
In 4 Packages Keep the file with the name windows.immersivecontrolpanel_cw5n1h2txyewy  (this cw5n1h2txyewy can vary from windows version to windows version)

If u want to keep cortana, any other windows app or u use 1903+ follow debloating guides for 1903+.

after these steps open DCKiller folder, and paste pssuspend.exe in windows folder ( C:\Windows ) and run it as administrator , Then paste DCKiller.exe in the main tab of ur C drive ( C:\ ).


Now open ur game, then u run DCKiller (and click start) and it disables DWM.

If u click 1 time in start it will disable DWM and kill explorer.exe, if u want to keep explorer.exe and still disable dwm just click 2 times in start and 1 time in stop.


After ur gaming session ALT TAB until u go to DCKiller tab and click stop and everything should be back to normal