# Changelogs:

Optiz Services Script Version 0.1.0
12th March 2020

* Replaced all sc config XXXX commands with "Reg add" commands
* Added a feature to disable Windows Store (thanks to SH37!)
* Removed Disable Windows sign-in \ log-in feature
