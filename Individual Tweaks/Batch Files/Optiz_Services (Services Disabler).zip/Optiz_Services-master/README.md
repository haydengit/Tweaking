# Optiz
**First of all, thank you for reading, please make sure you read it carefully before running this script!**
OptiZ Script is made to disable unneeded Windows 10 services, the Script may be differente then other Scripts, because in this Script you can choose which Services you want to disable and Services you want to keep.
# Why it's a good thing to disable services?
There is many services on Windows 10 today, some of them you really don't need, running a lot of services in the background may take a lot of resources, and disabling them should helps with performance and RAM etc.
Our future plans is to make our scripts as stable as possible to make the user experience even better.

listening to our community is something really importent to us, we want to know your suggestion and opinions on our script
Please join [Evolve communitiy](https://discord.gg/N5awGsk)

 It is recommended to run the script with [NSudo By M2Team](https://github.com/M2Team/NSudo) to disable more services like Task Scheduler.
Go to [MajorGeeks](https://m.majorgeeks.com/files/details/nsudo.html) and download NSudo

* Recommended: **Please make a system restore or a backup before you running the script so you can go back in anytime.** 

# How to run Optiz Script ?

1. Go to the main page of Optiz_Serivces, click on the top-right green bottom to download
2. Extract the .zip file somewhere on your PC, and open the folder.
3. Run Optiz Script.bat as an Administrator/
4. Once you open the .bat file, you will see a black window with the features, if you want to apply the tweak, type the letter "Y" - Yes, by typeing the letter "N" - No, the tweak won't apply and the service will stay like it was before.
Be careful with what you selecting, do it step-by-step, sometimes you don't have to choose everything yes.
5. Once the script finished, do a restart to your PC.

# Credits
* [n1kobg](https://n1kobg.blogspot.com/)
* [equk](https://github.com/equk/windows/tree/master/windows_10)
* [Revision](https://discord.gg/962y4pU)
* [Evolve communitiy](https://discord.gg/N5awGsk)
