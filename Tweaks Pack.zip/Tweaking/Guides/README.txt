Use WORDPAD or Notepad++ to see the guides, for an optimal experience with images to help you.

If you want to see his' guides library and the guides' updates, here is his guides library. 

https://drive.google.com/drive/folders/10K3ptMD8h2Bd_NELYGQcvqGCreEb12m6