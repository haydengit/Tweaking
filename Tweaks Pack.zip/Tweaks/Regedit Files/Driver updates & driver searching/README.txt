This can be disabled in gpedit too.
By this way:

Disable driver updates & driver searching
gpedit.msc
Computer Configuration/Administrative Templates/Windows/Windows Update
Do not include drivers with Windows Updates - enabled
