ThrottleStop 8.72
December 17, 2019

New Features
- enabled Limit Reasons access for 10th Gen Core i processors.
- added FIVR Control locked status reporting. 
- fixed maximum multiplier reporting in FIVR TRL window for 6 and 8 core CPUs.

ThrottleStop 8.71
November 7, 2019

New Features
- new option to set FIVR offset voltages to zero when entering Windows Sleep mode.
- reporting of maximum multiplier in FIVR Turbo Ratio Limits.
- updated link to The ThrottleStop Guide (2019) at Ultrabook Review.

Kevin Glynn
throttlestop@shaw.ca
